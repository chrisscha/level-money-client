package com.levelmoney.client.api.v2.core;

/**
 * Marker interface to make sure you actually return a response object from the service
 * <p>
 * Created by chris on 11/27/16.
 */
public interface ApiResponse {
}
