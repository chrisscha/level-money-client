package com.levelmoney.client.api.v2.core;

/**
 * Marker interface to make sure you actually pass in a request object to the service
 * <p>
 * Created by chris on 11/27/16.
 */
public interface ApiRequest {
}
